package co.in.stockmicroservices.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.in.stockmicroservices.dto.StocksExchangeResponse;
import co.in.stockmicroservices.dto.StocksResponse;
import co.in.stockmicroservices.entity.Stocks;
import co.in.stockmicroservices.entity.StocksExchange;
import co.in.stockmicroservices.repository.StocksRepository;

@Service
public class StocksServiceImpl implements IStocksService {

	@Autowired
	private StocksRepository stockRepository;

	@Autowired
	private StocksExchangeClient StocksExchangeClient;

	@Override
	public Stocks createStock(Stocks stock) {
		return stockRepository.save(stock);
	}

	@Override
	public List<Stocks> getAllStocks() {
		return stockRepository.findAll();
	}

	@Override
	public Optional<Stocks> getStockById(int stockId) {
		return stockRepository.findById(stockId);
	}

	@Override
	public Stocks updateStock(int stockId, Stocks stockDetails) {
		Stocks existingStock = stockRepository.findById(stockId).get();
		existingStock.setCompanyName(stockDetails.getCompanyName());
		existingStock.setCompanyPrice(stockDetails.getCompanyPrice());
		return stockRepository.save(existingStock);
	}

	@Override
	public void deleteStockById(int stockId) {
		stockRepository.deleteById(stockId);
	}

	@Override
	public StocksResponse getStocksExchange(int stockId, int exchangeId) {
		Stocks stocksObj = stockRepository.findById(stockId).get();

		StocksResponse stocksResponseObj = new StocksResponse();
		stocksResponseObj.setStockId(stocksObj.getStockId());
		stocksResponseObj.setCompanyName(stocksObj.getCompanyName());
		stocksResponseObj.setCompanyPrice(stocksObj.getCompanyPrice());
		
		StocksExchangeResponse stocksexchangeresponseObj = StocksExchangeClient.getStockExchangeById(exchangeId).getBody();
		stocksResponseObj.setStocksExchangeResponse(stocksexchangeresponseObj);
		return stocksResponseObj;

	}

}
